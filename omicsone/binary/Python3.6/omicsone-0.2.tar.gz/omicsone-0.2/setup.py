# from setuptools import setup
from distutils.core import setup

setup(name='omicsone',
      version='0.2',
      description='Omics Data Analysis in One-Click',
      url='http://github.com/huizhang_lab/omicsone',
      author='Yingwei Hu',
      author_email='yhu39@jhmi.edu',
      license='MIT',
      packages=['omicsone'],
      package_data={
          'omicsone': [
              'ui/*',
              'res/databases/enrichment/*',
              'res/sample_data/*',
              'params/*.txt',
              'tools/*.so',
              'tools/*.py',
              '*.so']
      },
      zip_safe=False)
