# Hello, world!
#
# This is an example function named 'hello'
# which prints 'Hello, world!'.
#
# You can learn more about package authoring with RStudio at:
#
#   http://r-pkgs.had.co.nz/
#
# Some useful keyboard shortcuts for package authoring:
#
#   Install Package:           'Ctrl + Shift + B'
#   Check Package:             'Ctrl + Shift + E'
#   Test Package:              'Ctrl + Shift + T'

config_path = "D:\\yhu39\\github\\GPNotebook-Private\\gpnotebook\\out\\cluster\\nmf_configs.yml"

hello <- function() {
  print("Hello, world!")
}

#' Load Configuration Settings
#'
#' This function reads a configuration file in YAML format, extracts various settings and data paths,
#' and reads specified data files into R. It returns a list containing data frames and settings for further processing.
#'
#' @param config_path The file path to the YAML configuration file.
#' @return A list containing:
#'   \itemize{
#'     \item \code{data}: expression data as a data frame,
#'     \item \code{out_dir}: output directory path,
#'     \item \code{nmf_params}: parameters for NMF analysis,
#'     \item \code{left_ann}: list containing left annotation data and settings,
#'     \item \code{top_ann}: list containing top annotation data and settings
#'   }
#' @importFrom yaml read_yaml
#' @importFrom utils read.table
#' @export
load_config <-function(config_path){
  # read config
  config <- yaml::read_yaml(config_path)
  # get output directory
  out_dir <- config$output$out_dir
  # get data path
  data_path <- config$input$expression_data
  data <- read.table(data_path, sep = "\t",
                     header = TRUE, row.names = 1)
  # get left annotation information
  left_ann_data <- read.table(config$input$left_annotation_data,
                              header = TRUE, row.names = NULL)
  left_ann_settings <- yaml::read_yaml(config$input$left_annotation_settings)
  # get top annotation information
  top_ann_data <- read.table(config$input$top_annotation_data,
                             header=TRUE, row.names = NULL)

  top_ann_settings <- yaml::read_yaml(config$input$top_annotatin_settings)

  # get nmf params
  nmf_params <- yaml::read_yaml(config$input$nmf_parameters)
  # return data
  return(list(data=data, out_dir = out_dir, nmf_params = nmf_params,
              left_ann= list(data = left_ann_data, settings = left_ann_settings),
              top_ann = list(data = top_ann_data, settings = top_ann_settings)
  ))
}

#' @export
nn_ztrans <- function(dataInput) {
  # Calculate row means with NA values removed
  rmean <- rowMeans(as.matrix(dataInput), na.rm = TRUE)

  # Calculate standard deviation for each row
  sx <- apply(as.matrix(dataInput), 1, sd, na.rm = TRUE)

  # Subtract the mean from each element in the row
  matrix.tmp <- sweep(as.matrix(dataInput), 1, rmean, FUN = "-")

  # Divide each element by its row standard deviation
  matrix.Z <- sweep(matrix.tmp, 1, sx, FUN = "/")

  # Generate positive matrix: replace negative values with 0
  posMx <- matrix.Z
  posMx[posMx < 0] <- 0

  # Generate negative matrix: replace positive values with 0, then take absolute values
  negMx <- matrix.Z
  negMx[negMx > 0] <- 0
  negMx <- abs(negMx)

  # Join two matrices
  final.join.Mx.Z <- rbind(posMx, negMx)

  return(list(z=matrix.Z, nn=final.join.Mx.Z))
}

#' @import graphics
#' @import grDevices
#' @importFrom NMF consensusmap
#' @export
plot_consensus_heatmap <- function(result, params ,out_dir) {
  k_range_min <- params$k_range$min
  k_range_max <- params$k_range$max
  # Construct the filename based on the directory and k range
  filename <- paste0(out_dir, "/", "NMF_consensusMap_k", k_range_min, "-", k_range_max, ".tiff")

  # Open a TIFF device with specified dimensions
  tiff(filename = filename, width = 1200, height = 1200, units = "px")

  # Generate the consensus map from the result object
  NMF::consensusmap(result,labCol=NA,labRow=NA)


  # Close the TIFF device to save the file
  dev.off()
}

#' @import graphics
#' @import grDevices
#' @export
plot_clusters_performance <- function(result, params, out_dir) {
  k_range_min <- params$k_range$min
  k_range_max <- params$k_range$max
  # Construct the filename based on the directory and k range
  filename <- paste0(out_dir, "/", "NMF_rankSurvey_k", k_range_min, "-", k_range_max, ".tiff")

  # Open a TIFF device with specified dimensions
  tiff(filename = filename, width = 800, height = 800, units = "px")

  # Plot the results
  print(plot(result) )

  # Close the TIFF device to save the file
  dev.off()
}

#' @importFrom NMF predict
#' @importFrom tibble rownames_to_column
#' @importFrom dplyr %>%
#' @export
process_NMF_results <- function( final.join.Mx.Z, result, out_dir) {
  fit.list <- unlist(result$fit)
  kcounter <- 1

  for(i in 1:length(fit.list)) {
    # Predict membership and probability for columns and features
    clusMem.c <- NMF::predict(fit.list[[i]], what = "columns", prob = TRUE)
    featMem.c <- NMF::predict(fit.list[[i]], what = "features", prob = TRUE)

    # Convert to data frames and adjust columns
    clusMem.c <- as.data.frame(clusMem.c) %>% tibble::rownames_to_column('Sample')
    colnames(clusMem.c) <- c("Sample", "NMF.cluster", "Membership.scores")

    featMem.c <- as.data.frame(featMem.c) %>% tibble::rownames_to_column('SeqOrder')
    featMem.c$Index <- rownames(final.join.Mx.Z)
    featMem.c <- featMem.c[, c(length(featMem.c), 1:(length(featMem.c)-1))]
    colnames(featMem.c) <- c("Index", "Index.order", "NMF.cluster", "Probability")

    # Write results to files
    write.table(clusMem.c, file = paste0(out_dir, "/", "NMF_K", kcounter, "_sample_NMFlabels_membershipscores.tsv"), sep = "\t", row.names = FALSE)
    write.table(featMem.c, file = paste0(out_dir, "/", "NMF_K", kcounter, "_feature_NMFlabels_probability.tsv"), sep = "\t", row.names = FALSE)

    kcounter <- kcounter + 1
  }
}

#' @export
find_optimal_k <- function(result, params, out_dir) {
  k_range_min <- params$k_range$min
  k_range_max <- params$k_range$max
  # Calculate the product of cophenetic correlation and dispersion coefficients
  product.c.d <- result$measures$cophenetic * result$measures$dispersion

  # Assign names to the products corresponding to each k value
  names(product.c.d) <- seq(k_range_min, k_range_max)

  # Write the product values to a TSV file
  write.table(product.c.d, file = paste0(out_dir, "/",
                                         "NMF_K", k_range_min, "-", k_range_max,
                                         "_product_cophenetic-dispersion.tsv"), sep = "\t")

  # Find the k value with the maximum product
  optK.product <- product.c.d[which.max(product.c.d)]

  # Retrieve the name of the k value, which is the optimal k
  optKnum <- names(optK.product)

  # Return the optimal k
  return(optKnum)
}


#' @importFrom NMF predict
#' @importFrom tibble rownames_to_column
#' @importFrom dplyr %>%
#'
#' @export
calculate_member_scores <- function(result_optK, optKnum, out_dir) {

  # Predict which NMF cluster each sample belongs to, with probability scores
  clusMem.optK <- NMF::predict(result_optK, what = "columns", prob = TRUE)
  clusMem.optK <- as.data.frame(clusMem.optK)
  clusMem.optK <- clusMem.optK %>% tibble::rownames_to_column('Sample')
  colnames(clusMem.optK) <- c("Sample", "NMF.cluster", "Membership.scores")

  # Write the membership scores to a TSV file
  write.table(clusMem.optK,
              file = paste0(out_dir, "/NMF_optK-", optKnum, "_sample_NMFlabels_membershipscores.tsv"),
              sep = "\t", row.names = FALSE)

  # return
  return(clusMem.optK)
}


#' @importFrom NMF predict
#' @importFrom tibble rownames_to_column
#' @importFrom dplyr %>%
#' @export
calculate_feature_probabilities <- function(result_optK, final_join_Mx_Z, optKnum,out_dir) {
  # Predict feature memberships with probabilities

  featMem.optK <- NMF::predict(result_optK, what = "features", prob = TRUE)
  featMem.optK <- as.data.frame(featMem.optK)

  # Convert the row names into a column and rearrange data
  featMem.optK <- featMem.optK %>% tibble::rownames_to_column('SeqOrder')
  featMem.optK$Index <- rownames(final_join_Mx_Z)
  featMem.optK <- featMem.optK[, c(length(featMem.optK), 1:(length(featMem.optK)-1))]
  colnames(featMem.optK) <- c("Index", "Index.order", "NMF.cluster", "Probability")

  # Write the probability data to a TSV file
  write.table(featMem.optK, file = paste0(out_dir, "/NMF_optK-", optKnum, "_feature_NMFlabels_probability.tsv"), sep = "\t", row.names = FALSE)

  return(featMem.optK)
}

#' @importFrom NMF extractFeatures
#' @importFrom dplyr left_join
#' @importFrom dplyr full_join
#' @importFrom dplyr arrange
#' @importFrom dplyr filter
#'
#' @export
extract_cluster_features <- function(result_optK, featMem_optK, params,out_dir) {
  extract.f <- NMF::extractFeatures(result_optK,method="kim") #method by Kim and Park (2007), but it could return NA/NULL because no features are unique to the clusters

  prob <- as.numeric(params$opt_k$feature_prob)
  extract.f.byProb <- NMF::extractFeatures(result_optK,prob)

  extract.f.final <- ""

  for(i in 1:length(extract.f))
  {
    if(i==1)
    {
      if(is.na(extract.f[[i]][1])) #if returned NA using specified method, extract features with probability > defined cutoff
      {
        extract.f.final <- data.frame(NMF.cluster=as.factor(i),Index.order=as.character(extract.f.byProb[[i]]))

        extract.f.final <- dplyr::left_join(extract.f.final, featMem_optK, by = c("Index.order","NMF.cluster"))

      }else{
        extract.f.final <- data.frame(NMF.cluster=as.factor(i),Index.order=as.character(extract.f[[i]]))

        extract.f.final <- dplyr::left_join(extract.f.final, featMem_optK, by = c("Index.order","NMF.cluster"))
      }
    }else{
      if(is.na(extract.f[[i]][1])) #if returned NA using specified method, extract features with probability > defined cutoff
      {
        tmp <- data.frame(NMF.cluster=as.factor(i),Index.order=as.character(extract.f.byProb[[i]]))

        tmp <- dplyr::left_join(tmp, featMem_optK, by = c("Index.order","NMF.cluster"))

        extract.f.final <- dplyr::full_join(extract.f.final,tmp)
      }else{
        tmp <- data.frame(NMF.cluster=as.factor(i),Index.order=as.character(extract.f[[i]]))

        tmp <- dplyr::left_join(tmp, featMem_optK, by = c("Index.order","NMF.cluster"))

        extract.f.final <- dplyr::full_join(extract.f.final,tmp)
      }
    }
  }


  write.table(extract.f.final,
              file=paste0(out_dir,"/","NMF_optK-",params$opt_k$value, "_extractFeatures.tsv"),
              sep="\t",row.names = FALSE)

  #remove duplicates (based on index) among the clusters, only keep the one with largest probability
  extract.f.final.noDuplicate <- extract.f.final %>% arrange(Index, -Probability) %>% filter(!duplicated(Index))

  extract.f.final.noDuplicate <- extract.f.final.noDuplicate[order(extract.f.final.noDuplicate$NMF.cluster),]

  write.table(extract.f.final.noDuplicate,
              file=paste0(out_dir,"/","NMF_optK-", params$opt_k$value, "_extractFeatures_noDuplicates.tsv"),sep="\t",
              row.names = FALSE)

  return(list(complete = extract.f.final, no_duplicate = extract.f.final.noDuplicate))
}


#' @export
table_to_map <- function(df, key_col, value_col){
  a_map <- list()

  for (i in 1:nrow(df)){
    key <- df[[key_col]][i]
    value <- df[[value_col]][i]
    a_map[[key]] <- value
  }

  return(a_map)
}

#' @importFrom dplyr %>%
#' @export
sort_features <- function(features_table, left_ann) {

  # Assuming 'Index' column contains the '@' separated values
  split_values <- strsplit(features_table$Index, '@')

  # Extract the 'c' part from the split values and create a new column for Glycan
  features_table$Glycan <- sapply(split_values, function(x) x[[5]])

  # Map glycan properties using the provided mapping tables
  glycan_type_color <- left_ann$settings$glycan_type_color
  glycan_type_index <- left_ann$settings$glycan_type_index
  glycan_type_map <- table_to_map(left_ann$data,key_col = 'Glycopeptide',
                                  value_col= 'GlycanType')

  features_table$GlycanType <- as.character(glycan_type_map[features_table$Index])
  features_table$GlycanTypeIndex <- as.character(glycan_type_index[features_table$GlycanType])
  features_table$GlycanTypeColor <- as.character(glycan_type_color[features_table$GlycanType])

  # Sort the features_table by NMF.cluster and GlycanTypeIndex
  sorted_features_table <- features_table %>%
    arrange(NMF.cluster, GlycanTypeIndex)

  # Optionally return only the 'Index' column from the sorted table if that's the desired output
  # sorted_features <- sorted_features_table$Index

  return(sorted_features_table)
}

#' @importFrom dplyr %>%
#' @importFrom dplyr arrange
#' @export
sort_samples <- function(clusMem.optK){

  sorted.clusMem.optK <- clusMem.optK %>%
    arrange(NMF.cluster, desc(Membership.scores))

  # Assuming you have the sorted_df dataframe from the previous step
  # Extract the sorted Sample.ID column

  return(sorted.clusMem.optK$Sample)
}

#' @export
sort_data <- function(matrix.Z, sorted.features, sorted.samples){
  # Reorder the columns of matrix.Z based on the sorted Sample.ID order
  matrix.Z.sorted <- matrix.Z[match(sorted.features, rownames(matrix.Z)),
                              match(sorted.samples, colnames(matrix.Z))]

  # Return both the modified full data frame and the sorted indices
  return(matrix.Z.sorted)
}

#' @export
standardize_col <- function(df, col_name='Sample.ID') {

  # Check if the column exists
  if (!col_name %in% names(df)) {
    stop("Specified column does not exist in the dataframe")
  }

  # Apply transformations using base R
  df[[col_name]] <- gsub("-", ".", df[[col_name]])

  # Return the modified dataframe
  return(df)
}

#' @export
sort_dataframe_by_col <- function(df,order, col_name="Sample.ID"){
  # Check if the specified column exists in the dataframe
  if (!col_name %in% names(df)) {
    stop("Specified column does not exist in the dataframe")
  }

  # Convert the specified column to a factor with the given order
  df[[col_name]] <- factor(df[[col_name]], levels = order)

  # Sort the dataframe by the newly created factor
  df_sorted <- df[order(df[[col_name]]), ]

  # Return the sorted dataframe
  return(df_sorted)
}

#' @export
prepare_ann_df <- function(ann_data, sorted_index, other_data,
                           this_col_name, other_col_name){
  df <- ann_data
  df <- sort_dataframe_by_col(df, order = sorted_index,
                              col_name = this_col_name)
  df <- merge(df, other_data, by.x = this_col_name,
              by.y = other_col_name, sort=FALSE, all.x=TRUE)
  row.names(df) <- df[[this_col_name]]
  return(df)
}


#' @export
prepare_top_ann_df <- function(top_ann_data, sorted_samples, clusMem_optK,
                               topAnn_col_name = 'Sample.ID',
                               clusMem_col_name = 'Sample'){
  df <- standardize_col(top_ann_data,col_name = topAnn_col_name)
  df <- prepare_ann_df(df, sorted_index = sorted_samples,
                       other_data = clusMem_optK,
                       this_col_name = topAnn_col_name,
                       other_col_name = clusMem_col_name )
  col_names <- names(df)[!names(df) %in% c(topAnn_col_name, "Membership.scores")]
  df <- df[,col_names]
  return(df)
}


#' @export
prepare_left_ann_df <- function(feature_table){
  df <- feature_table
  row.names(df) <- df[['Index']]
  col_names <- c('NMF.cluster','GlycanType')
  df <- df[,col_names]
  return(df)
}


#' @export
prepare_ann_colors <- function(settings){
  names_list <- sort(names(settings))
  new_list <- list()
  for (name in names_list){
    if (name == 'glycan_type_color'){
      new_list[["GlycanType"]] <- unlist(settings[[name]])
    }else{
      new_list[[name]] <- unlist(settings[[name]])
    }
  }
  return(new_list)
}


#' @export
prepare_top_ann_colors <- function(settings){
  new_list <- prepare_ann_colors(settings)
  new_list[['NMF.cluster']] = unlist(list('1'='red','2' ='green','3'='blue',
                                   '4'='brown','5'='pink'))
  return(new_list)
}

#' @export
prepare_left_ann_colors <- function(settings){
  new_list <- prepare_ann_colors(settings)
  new_list[['NMF.cluster']] = unlist(list('1'='red','2' ='green','3'='blue',
                                              '4'='brown','5'='pink'))
  return(new_list)
}

#' Plot Summary Heatmap and Save as TIFF
#'
#' This function generates a heatmap from the provided data frame and saves it as a TIFF file.
#' The heatmap does not cluster rows or columns and limits data values between -1 and 1.
#' Annotations for the top and left sides of the heatmap are added based on provided data and color settings.
#'
#' @param data_frame A data frame containing the data to be plotted in the heatmap. Data values are adjusted to be within the range [-1, 1].
#' @param top_ann_data Data frame containing the data for the top annotation of the heatmap.
#' @param left_ann_data Data frame containing the data for the left annotation of the heatmap.
#' @param top_ann_colors A list of colors for the top annotation, corresponding to the `top_ann_data`.
#' @param left_ann_colors A list of colors for the left annotation, corresponding to the `left_ann_data`.
#' @param out_dir A character string specifying the directory where the TIFF file will be saved.
#'
#' @import graphics
#' @import grDevices
#' @importFrom ComplexHeatmap Heatmap
#' @importFrom ComplexHeatmap HeatmapAnnotation
#' @importFrom ComplexHeatmap rowAnnotation
#' @export
plot_summary_heatmap <- function(data_frame, top_ann_data, left_ann_data,
                                 top_ann_colors, left_ann_colors,
                         out_dir){
  # Specify the TIFF file path and dimensions
  tiff_file <- paste0(out_dir, "/", "cluster_optK_heatmap.tiff")
  tiff_width <- 800  # Width in pixels
  tiff_height <- 600  # Height in pixels

  # Save the heatmap as a TIFF image
  tiff(filename = tiff_file, width = tiff_width, height = tiff_height,
       units = "px")

  # Sample dataframe
  # df <- matrix.Z.sorted
  df <- data_frame

  df <- ifelse(df > 1, 1, ifelse(df < -1, -1, df))


  print(Heatmap(df,
          show_column_names = FALSE,
          show_column_dend = FALSE,
          cluster_columns = FALSE,
          show_row_names = FALSE,
          show_row_dend = FALSE,
          cluster_rows = FALSE,
          # name='Z-Scored',
          top_annotation = HeatmapAnnotation(df = top_ann_data,col = top_ann_colors),
          left_annotation = rowAnnotation(df = left_ann_data, col = left_ann_colors),
  ))


  dev.off()
}

#' Execute Full NMF Analysis Pipeline
#'
#' This function orchestrates a full workflow for NMF (Non-negative Matrix Factorization) analysis based on specified configurations. It handles the loading of configuration settings, normalization of data, execution of NMF analysis, generation of various plots, and more. It also provides console output at each major step for debugging purposes.
#'
#' @param config_path A string specifying the path to the YAML configuration file which contains all necessary parameters and settings for running the analysis.
#' @param seed An optional integer seed for reproducibility of the NMF analysis. Defaults to 123456.
#'
#' @return The output directory as a string, indicating where all generated files have been saved.
#'
#' @details
#' The function performs the following steps:
#' 1. Loads configuration from the specified path.
#' 2. Normalizes data using `nn_ztrans`.
#' 3. Runs NMF analysis across a range of k values.
#' 4. Generates consensus and performance plots.
#' 5. Processes NMF results and extracts optimal k value.
#' 6. Runs NMF analysis with the optimal k.
#' 7. Calculates membership scores and feature probabilities.
#' 8. Extracts and sorts cluster features.
#' 9. Prepares and plots the final summary heatmap.
#' Each step is accompanied by console messages that provide status updates and help in debugging.
#'
#' @examples
#' # Assuming 'config.yml' is your configuration file located at "path/to/config.yml"
#' out_dir <- run_all("path/to/config.yml")
#'
#' @importFrom NMF nmf
#' @export
run_all <- function(config_path,seed=123456){
  # load configuration
  cat("Loading configuration...\n")
  config <- load_config(config_path)
  nmf_params <- config$nmf_params
  out_dir <- config$out_dir

  cat("Running nn_ztrans...\n")
  matrix <- nn_ztrans(config$data)

  cat("Running NMF analysis tests...\n")
  result <- NMF::nmf(matrix$nn, seq(nmf_params$k_range$min,nmf_params$k_range$max),
                method='brunet', nrun=nmf_params$test$nruns, seed=seed)

  cat("Plotting consensus heatmap...\n")
  plot_consensus_heatmap(result,nmf_params, out_dir)
  cat("Plotting clusters performance...\n")
  plot_clusters_performance(result,nmf_params, out_dir)

  cat("Processing NMF test run results...\n")
  process_NMF_results(matrix$nn, result, out_dir)

  cat("Finding optimal k...\n")
  nmf_params$opt_k$value <- find_optimal_k(result, nmf_params, out_dir)
  opt_k <- nmf_params$opt_k$value

  cat("Running NMF analysis with optimal k...\n")
  result.opt_k <- NMF::nmf(matrix$nn, as.integer(opt_k), method = 'brunet',
                      nrun = nmf_params$opt_k$nruns, seed = seed)

  cat("Calculating member scores...\n")
  clusMem.opt_k <- calculate_member_scores(result.opt_k, opt_k,out_dir)
  cat("Calculating feature probabilities...\n")
  featMem.opt_k <- calculate_feature_probabilities(
    result.opt_k,matrix$nn,opt_k,out_dir)

  cat("Extracting cluster features...\n")
  features <- extract_cluster_features(result.opt_k, featMem.opt_k,
                                                   nmf_params, out_dir)

  cat("Sorting features...\n")
  sorted.features_table <- sort_features(features$no_duplicate,
                                                     config$left_ann)
  sorted.features <- sorted.features_table$Index

  cat("Sorting samples...\n")
  sorted.samples <- sort_samples(clusMem.opt_k)

  cat("Sorting data matrix...\n")
  sorted.matrix = sort_data(matrix$z, sorted.features,sorted.samples)

  cat("Preparing top annotation data...\n")
  top_ann_data <- prepare_top_ann_df(config$top_ann$data, sorted.samples,
                                                 clusMem.opt_k )
  cat("Preparing top annotation colors...\n")
  top_ann_colors <- prepare_top_ann_colors(config$top_ann$settings)

  cat("Preparing left annotation data...\n")
  left_ann_data <- prepare_left_ann_df(sorted.features_table)

  cat("Preparing left annotation colors...\n")
  left_ann_colors <- prepare_left_ann_colors(config$left_ann$settings)

  cat("Plotting summary heatmap...\n")
  plot_summary_heatmap(sorted.matrix, top_ann_data,left_ann_data,
                                   top_ann_colors,left_ann_colors,out_dir)
  cat("Finished all operations successfully. Output directory: ", out_dir, "\n")
  return(out_dir)
}


