import sys, os, re

from ipywidgets import Tab
from IPython.display import display
import ipywidgets as widgets
from ipywidgets import HBox, VBox, Layout
from ipywidgets import Label, Dropdown, Text, Textarea, IntProgress, Button, FloatText, Accordion

from ..omicsone import run

settings = {}
dropdown_data_types = []
text_data_matrices = []


def one_click():
    global settings

    label_param = Label(
        value='Parameter File Path',
        layout=Layout(width='20%')
    )

    text_param = Text(
        value='',
        layout=Layout(width="80%")
    )

    button_run = widgets.Button(
        description='Run OmicsOne',
        disabled=False,
        button_style='',
        tooltip='Run OmicsOne',
    )

    # tab1 = VBox([
    #         HBox([label_param, text_param]),
    #         button_run])
    tab1 = HBox([label_param, text_param,button_run])

    tab_main = Tab([tab1])
    tab_main.set_title(0,'OmicsOne')

    def on_button_run(btn):
        wd = os.path.dirname(os.path.abspath(__file__))
        path = str(text_param.value)
        if not os.path.exists(path):
            path = wd + "/../params/" + path
            if not os.path.exists(path):
                print('Paramter File Not Found: {}'.format(path))
                return
        options = {'parameter': path}
        print('Parameter File Found!: {}'.format(path))
        # options = {'parameter': '/home/yingwei/newdrive/bitbucket/omicsone/omicsone/params/param.txt'}
        args = []
        run(options, args)

    button_run.on_click(on_button_run)

    display(tab_main)


def gui():
    global settings
    global dropdown_data_types
    global text_data_matrices

    tab_data = new_tab_data()
    tab_method = new_tab_method()
    # tab_report = new_tab_report(settings)

    tab_main = Tab()
    # tab_main.children = [tab_data,tab_method,tab_report]
    tab_main.children = [tab_data]
    tab_main.set_title(0, 'Data')

    button_refresh = widgets.Button(
        description='Run OmicsOne',
        disabled=False,
        button_style='',
        tooltip='Run OmicsOne',
    )

    view = VBox(children=[
        tab_main,
        button_refresh
    ])

    def on_button_refresh(btn):
        tab_data.children = tuple(list(tab_data.children[0].children) + [Text('3')])

    button_refresh.on_click(on_button_refresh)

    display(view)


def new_tab_data():
    global settings
    global dropdown_data_types
    global text_data_matrices
    data_types = ['meta', 'protein', 'RNASeq']
    label_data_type = Label(
        value='Data Type',
        layout=Layout(width='35%')
    )

    label_data_matrix = Label(
        value='Data Path',
        layout=Layout(width="100%")
    )

    dropdown_data_types = []
    text_data_matrices = []

    for i in range(len(data_types)):
        dropdown_data_types.append(
            Dropdown(
                options=data_types,
                value=data_types[i]
            )
        )
        text_data_matrices.append(
            Text(
                value='',
                layout=Layout(width="100%")
            )
        )

    accordion_input_files = Accordion(
        children=[
            VBox([HBox([label_data_type, label_data_matrix])]
                 + [HBox([dropdown_data_types[i], text_data_matrices[i]]) for i in range(len(dropdown_data_types))]
                 )
        ]
    )
    accordion_input_files.set_title(0, 'Input Files')

    return VBox(children=[accordion_input_files
                          ])


def new_tab_method():
    pass
