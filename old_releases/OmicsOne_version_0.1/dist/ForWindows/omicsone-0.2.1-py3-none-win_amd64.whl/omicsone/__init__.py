from multiprocessing import freeze_support
import re, os, sys
import warnings

# import easydev
warnings.filterwarnings("ignore")
os.environ["JOBLIB_MULTIPROCESSING"] = "0"


def run(options, args):
    try:
        from tools import OmicsOneParameter
        from tools import preprocess
        from tools import pca
        from tools import de2
        from tools import dem
        from tools import count
        from tools import sample_corr
        # from tools import cluster
        from tools import feature_corr
        from tools import myheatmap
        from tools import info_count
        from tools import sample_cv
        from tools import run_cancersubtypes
        from tools import quick_import_param
    except:

        from .tools import OmicsOneParameter
        from .tools import preprocess
        from .tools import pca
        from .tools import de2
        from .tools import dem
        from .tools import count
        from .tools import sample_corr
        # from tools import cluster
        from .tools import feature_corr
        from .tools import myheatmap
        from .tools import info_count
        from .tools import sample_cv
        from .tools import run_cancersubtypes
        from .tools import quick_import_param

    freeze_support()

    try:
        option_dict = vars(options)
    except TypeError:
        option_dict = options

    param_path = option_dict.get('parameter', None)
    # if param_path is None or not os.path.exists(param_path):
    #     print('Error! Fail to load parameters from {}'.format(param_path))
    #     sys.exit(1)
    # param = OmicsOneParameter(param_path)

    param = quick_import_param(param_path)

    # # check file existence
    # for i in param['data']:
    #     fn = param['data'][i]['path']
    #     method = "FILE_EXISTENCE_CHECK"
    #     if os.path.exists(fn):
    #         result = "SUCCESS"
    #         param['data'][i][method] = result
    #         print('{0}: input={1},result={2}'.format(method, fn, result))
    #     else:
    #         result = "FAIL"
    #         param['data'][i][method] = result
    #         print('{0}: input={1},result={2}'.format(method, fn, result))
    #
    # # preprocess data
    # for data_id in param['data']:
    #     if param['data'][data_id]['FILE_EXISTENCE_CHECK'] != "SUCCESS":
    #         continue
    #     # the file is not involved in the analysis
    #     if data_id not in param['method']:
    #         continue
    #     if data_id in param['method']:
    #         preprocess_param = param['method'][data_id].get('preprocess', None)
    #         if preprocess_param:
    #             fn = param['data'][data_id]['path']
    #             df = preprocess(file_name=fn, param=preprocess_param)
    #             param['data'][data_id]['preprocessed'] = df

    # print('Processing...')
    # analyze data
    # quality control
    for data_id in param['data']:
        if param['data'][data_id]['FILE_EXISTENCE_CHECK'] != "SUCCESS":
            continue
        if 'preprocessed' not in param['data'][data_id]:
            continue
        if param['data'][data_id]['preprocessed'] is None:
            continue
        if data_id not in param['method']:
            continue
        df = param['data'][data_id]['preprocessed']
        info_df = param['data']['0']['preprocessed']
        if 'heatmap' in param['method'][data_id]:
            heatmap_param = param['method'][data_id].get('heatmap', None)
            if heatmap_param is not None:
                if 'fout' not in heatmap_param:
                    heatmap_param['fout'] = param['report']['out_dir'] + '/heatmap_{}.png'.format(data_id)
            myheatmap(df, info_df, heatmap_param)
        if 'info_count' in param['method'][data_id]:
            corr_param = param['method'][data_id].get('info_count', None)
            if corr_param is not None:
                if 'fout' not in corr_param:
                    corr_param['fout'] = param['report']['out_dir'] + '/info_corr_{}.csv'.format(data_id)
            info_count(df, corr_param)
        if 'count' in param['method'][data_id]:
            count_param = param['method'][data_id].get('count', None)
            if count_param is not None:
                if 'fout' not in count_param:
                    count_param['fout'] = param['report']['out_dir'] + '/count_{}.png'.format(data_id)
            count(df, info_df, count_param)
        if 'feature_corr' in param['method'][data_id]:
            feature_corr_param = param['method'][data_id].get('feature_corr', None)
            if feature_corr_param is not None:
                if 'fout' not in feature_corr_param:
                    feature_corr_param['fout'] = param['report']['out_dir'] + '/feature_corr_{}.png'.format(data_id)
            feature_corr(df, info_df, feature_corr_param)
        if 'sample_corr' in param['method'][data_id]:
            sample_corr_param = param['method'][data_id].get('sample_corr', None)
            if sample_corr_param is not None:
                if 'fout' not in sample_corr_param:
                    sample_corr_param['fout'] = param['report']['out_dir'] + '/sample_corr_{}.png'.format(data_id)
            sample_corr_param['data_type'] = param['data'][data_id]['type']
            sample_corr(df, info_df, sample_corr_param)
        if 'sample_cv' in param['method'][data_id]:
            sample_cv_param = param['method'][data_id].get('sample_cv', None)
            if sample_cv_param is not None:
                if 'fout' not in sample_cv_param:
                    sample_cv_param['fout'] = param['report']['out_dir'] + '/sample_cv_{}.png'.format(data_id)
            sample_cv_param['data_type'] = param['data'][data_id]['data_type']
            sample_cv(df, info_df, sample_cv_param)
        if 'pca' in param['method'][data_id]:
            pca_param = param['method'][data_id].get("pca", None)
            if pca_param is not None:
                if 'fout' not in pca_param:
                    pca_param['fout'] = param['report']['out_dir'] + '/pca_{}.png'.format(data_id)
            pca(df, info_df, pca_param)
        if 'de2' in param['method'][data_id]:
            de2_param = param['method'][data_id].get('de2', None)
            if de2_param is not None:
                if 'fout' not in de2_param:
                    de2_param['fout'] = param['report']['out_dir'] + "/de2_{}.png".format(data_id)
            de2(df, info_df, de2_param,{})
        if 'dem' in param['method'][data_id]:
            count_param = param['method'][data_id].get('dem', None)
            if count_param is not None:
                if 'fout' not in count_param:
                    count_param['fout'] = param['report']['out_dir'] + '/dem_{}.png'.format(data_id)
            dem(df, info_df, count_param)
        if 'CancerSubtypes' in param['method'][data_id]:
            cluster_param = param['method'][data_id].get('CancerSubtypes', None)
            if cluster_param is not None:
                if 'fout' not in cluster_param:
                    cluster_param['fout'] = param['report']['out_dir'] + '/CancerSubtypes_{}.png'.format(data_id)
            run_cancersubtypes(df, info_df, cluster_param)

if __name__ == "__main__":
    from optparse import OptionParser

    freeze_support()
    parser = OptionParser()
    parser.add_option("-p", "--param", dest="parameter",
                      help="read parameter from PARRAM", metavar="PARAM")
    parser.add_option("-q", "--quiet",
                      action="store_false", dest="verbose", default=True,
                      help="don't print status messages to stdout")

    (options, args) = parser.parse_args()
    print(options)
    print(type(options))
    print(args)
    print(type(args))
    run(options, args)
    sys.exit(0)
